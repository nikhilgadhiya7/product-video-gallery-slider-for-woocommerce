﻿=== WooCommerce Product Video Gallery ===
Contributors: nikhilgadhiya
Donate link: https://www.paypal.com/paypalme2/NikhilGadhiya
Tags: product-video,woocommerce-product,video-slider,youtube,woocommerce,wc,ecommerce,products,product-slider,woocommerce-product-slider,woocommerce-carousel
Requires at least: 4.9
Tested up to: 5.3.2
Requires PHP: 5.2.4
Stable tag: 1.1.3
Date: 30/01/2020
License: GPLv3 or later License
URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

WooCommerce Product Video Gallery – Embed videos to product gallery along with images on product single page of WooCommerce.
You can add only one video to per product gallery or you can mix videos and images combine as product gallery.
Adding Product Video and Instantly transform the gallery on your WooCommerce Product page into a fully Responsive Stunning Carousel.
When user sees brief video of your product then chances to sell product increases and it will also good for marketing of product. The features of plugin are really cool and easy to use.
Product details page will show that gallery video. 


= Basic Features =

Embed YouTube videos to product gallery along with images and videos together in single product gallery

Supports all type YouTube videos URL.

images and videos together in single product gallery.

Does not require to overwrite any WooCommerce core files

You can set Slider layout (Vertical or Horizontal), Slider auto play, Arrow enable/Disable for slider, Slider loop, Lightbox, Zoom, Arrow color, Arrow background color and many more options.

Add the URL of YouTube video of Product in the specific field of the product configuration page and your customers will have the pleasure to watch something dynamic and customized.

Adding Product Video and Instantly transform the gallery on your WooCommerce Product page into a fully Responsive Stunning Carousel


= Support =

For any queries feel free to drop a line at <a href="mailto:nikhilgadhiya7@gmail.com">nikhilgadhiya7@gmail.com</a>. 


== Installation ==

= Automatic Installation =

* Go to your plugin browser inside your wordpress installation and search `WooCommerce Product Video Gallery` by keyword. Then choose "WooCommerce Product Video Gallery" and click install. It will be installed shortly.
* Activate the plugin from `Plugins` menu after installation

= Manual Installation =

* Download the latest version and extract the folder to the `/wp-content/plugins/` directory
* The plugin will appear as inactive in your `Plugins` menu
* Activate the plugin through the `Plugins` menu in WordPress

== Setup and Configuration ==

Go to: WooCommerce > Settings > Products > WC Video Gallery Slider
Tick the checkbox to configure a setting.
Save changes

== Usage ==
For adding a video to your product : open edit product page and insert your product youtube video url in {Product Video Url} field

== Screenshots ==

1. Show video thumbnail with product nav gallery horizontal view.
2. show video on product gallery.
3. playing video on product gallery.
4. Show video thumbnail with product nav gallery vertical left view.
5. plugin setting.
6. Responsive.


== Changelog ==

= 1.1.3 =
* Tested latest version compatibility.
* video added inside the lightbox.

= 1.1.2 =
* Stable tag update.

= 1.1.1 =
* Tested latest version compatibility.
* Bug fixes and code improvement.

= 1.1.0 =
* Tested latest version compatibility.
* Bug fixes and code improvement.
* pugin name changed

= 1.0.2 =
* Tested latest version compatibility.
* Bug fixes and code improvement.

= 1.0.1 =
* Tested latest version compatibility.
* fixed bugs.

= 1.0 =
* Finalized stable Release.

== Upgrade Notice ==

= 1.1.1 =
* Thank you for using *WooCommerce Product Video Gallery* This release include general Bug fixes and code improvement.

= 1.0.2 =
* Thank you for using *WooCommerce Product Video Gallery* This release include general Bug fixes and code improvement.

= 1.0 =
Finalized Stable Release.